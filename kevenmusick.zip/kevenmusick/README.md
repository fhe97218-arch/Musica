# KEVEN Music 🎵

Android music player foundation designed for a Spotify-like experience with original UI/code.

## Included in this first complete foundation

- Jetpack Compose UI
- Home / Search / Library tabs
- Track cards, favorites and mini-player
- Real Media3 ExoPlayer playback
- Background media playback through `MediaSessionService`
- Local demo audio so the APK works without a music license/catalog
- DASH/HLS dependencies ready for an authorized streaming backend
- Clean separation between data, player and UI layers
- GitHub Actions workflow for debug APK builds

## Important

The project intentionally does **not** scrape, copy, or redistribute Spotify's catalog. To ship commercial music, connect `MusicRepository` to a catalog/API/storage service that grants the necessary playback and distribution rights.

## Build

Open the project in a current Android Studio release and let Gradle sync. The project targets Android API 37 and uses AGP 9.3.0 / Gradle 9.5.

Local build:

```bash
./gradlew :app:assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub

Repository name: `kevenmusick`

Push the contents of this folder to GitHub. The included workflow builds a debug APK and publishes it as a workflow artifact.
