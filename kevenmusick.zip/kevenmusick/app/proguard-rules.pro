# KEVEN Music release rules. Media3 and Compose provide their own consumer rules.
