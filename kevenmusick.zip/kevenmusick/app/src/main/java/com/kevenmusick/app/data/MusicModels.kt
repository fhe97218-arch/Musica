package com.kevenmusick.app.data

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: String,
    val liked: Boolean = false,
    val genre: String = "Demo"
)

data class Playlist(val id: String, val name: String, val trackIds: List<String>)
