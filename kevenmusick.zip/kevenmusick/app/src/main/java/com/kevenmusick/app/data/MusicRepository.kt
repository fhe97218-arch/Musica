package com.kevenmusick.app.data

import android.content.Context

class MusicRepository(private val context: Context) {
    private val tracks = listOf(
        Track("demo-01", "Neon Dawn", "KEVEN", "KEVEN Sessions", 180_000, "android.resource://${context.packageName}/raw/keven_demo", genre = "Electronic"),
        Track("demo-02", "Midnight Drive", "KEVEN", "KEVEN Sessions", 180_000, "android.resource://${context.packageName}/raw/keven_demo", genre = "Chill"),
        Track("demo-03", "Skyline", "KEVEN", "KEVEN Sessions", 180_000, "android.resource://${context.packageName}/raw/keven_demo", genre = "Pop"),
        Track("demo-04", "Afterglow", "KEVEN", "KEVEN Sessions", 180_000, "android.resource://${context.packageName}/raw/keven_demo", genre = "Ambient")
    )

    fun featured(): List<Track> = tracks
    fun search(query: String): List<Track> = if (query.isBlank()) tracks else tracks.filter {
        listOf(it.title, it.artist, it.album, it.genre).any { value -> value.contains(query, ignoreCase = true) }
    }
}
