package com.kevenmusick.app

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.kevenmusick.app.data.Track
import com.kevenmusick.app.player.KevenMusicService
import com.kevenmusick.app.player.toMediaItem
import com.kevenmusick.app.ui.MusicViewModel
import com.kevenmusick.app.ui.MusicUiState
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KevenMusicApp() }
    }
}

@Composable
private fun KevenMusicApp(vm: MusicViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val controllerState = rememberMediaController()
    var tab by remember { mutableIntStateOf(0) }

    MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(background = androidx.compose.ui.graphics.Color(0xFF09090B))) {
        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color(0xFF09090B),
            topBar = { KevenTopBar() },
            bottomBar = {
                Column(Modifier.navigationBarsPadding()) {
                    state.current?.let { MiniPlayer(it, controllerState.controller) }
                    NavigationBar(containerColor = androidx.compose.ui.graphics.Color(0xFF121214)) {
                        val labels = listOf("Inicio", "Buscar", "Biblioteca")
                        labels.forEachIndexed { index, label ->
                            NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Text(listOf("⌂", "⌕", "♫")[index]) }, label = { Text(label) })
                        }
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(state, vm, controllerState.controller, Modifier.padding(padding))
                1 -> SearchScreen(state, vm, controllerState.controller, Modifier.padding(padding))
                else -> LibraryScreen(state, vm, controllerState.controller, Modifier.padding(padding))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KevenTopBar() {
    TopAppBar(title = { Text("KEVEN Music", fontWeight = FontWeight.Bold) })
}

@Composable
private fun HomeScreen(state: MusicUiState, vm: MusicViewModel, controller: MediaController?, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Spacer(Modifier.height(10.dp))
            Text("Buenas 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Escucha algo nuevo", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { FeaturedCard(state.tracks.firstOrNull(), controller, vm) }
        item { Text("Recomendado para ti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(state.tracks) { track -> TrackRow(track, controller, vm) }
        item { Spacer(Modifier.height(90.dp)) }
    }
}

@Composable
private fun SearchScreen(state: MusicUiState, vm: MusicViewModel, controller: MediaController?, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(value = state.query, onValueChange = vm::setQuery, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Canciones, artistas o álbumes") })
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(state.tracks) { TrackRow(it, controller, vm) } }
    }
}

@Composable
private fun LibraryScreen(state: MusicUiState, vm: MusicViewModel, controller: MediaController?, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Tu biblioteca", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Text("❤️ Canciones que te gustan", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(state.tracks.filter { it.liked }) { TrackRow(it, controller, vm) } }
        if (state.tracks.none { it.liked }) Text("Todavía no tienes favoritos. Pulsa ♡ en una canción.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun FeaturedCard(track: Track?, controller: MediaController?, vm: MusicViewModel) {
    if (track == null) return
    Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.Color(0xFF6D28D9), androidx.compose.ui.graphics.Color(0xFF111827))))) {
            Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                Text("KEVEN SESSIONS", style = MaterialTheme.typography.labelMedium)
                Text(track.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(track.artist)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { playTrack(track, controller, vm) }) { Text("▶ Reproducir") }
            }
        }
    }
}

@Composable
private fun TrackRow(track: Track, controller: MediaController?, vm: MusicViewModel) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { playTrack(track, controller, vm) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.Color(0xFF7C3AED), androidx.compose.ui.graphics.Color(0xFF0F172A)))), contentAlignment = Alignment.Center) { Text("♫", style = MaterialTheme.typography.headlineSmall) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(track.title, fontWeight = FontWeight.SemiBold); Text("${track.artist} • ${track.album}", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
        IconButton(onClick = { vm.toggleLike(track.id) }) { Text(if (track.liked) "♥" else "♡") }
        Text("▶", modifier = Modifier.padding(horizontal = 6.dp))
    }
}

@Composable
private fun MiniPlayer(track: Track, controller: MediaController?) {
    var playing by remember(track.id) { mutableStateOf(false) }
    DisposableEffect(controller) {
        val listener = object : Player.Listener { override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying } }
        controller?.addListener(listener)
        onDispose { controller?.removeListener(listener) }
    }
    Surface(tonalElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(track.title, fontWeight = FontWeight.Bold); Text(track.artist, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Text(if (playing) "Ⅱ" else "▶") }
        }
    }
}

private fun playTrack(track: Track, controller: MediaController?, vm: MusicViewModel) {
    vm.selectTrack(track)
    controller?.apply { setMediaItem(track.toMediaItem()); prepare(); play() }
}

data class ControllerState(val controller: MediaController?)

@Composable
private fun rememberMediaController(): ControllerState {
    val context = androidx.compose.ui.platform.LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    LaunchedEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, KevenMusicService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        val executor = Executors.newSingleThreadExecutor()
        future.addListener({ controller = runCatching { future.get() }.getOrNull(); executor.shutdown() }, executor)
    }
    DisposableEffect(Unit) { onDispose { controller?.release() } }
    return ControllerState(controller)
}

