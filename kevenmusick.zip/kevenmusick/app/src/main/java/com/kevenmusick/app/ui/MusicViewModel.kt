package com.kevenmusick.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kevenmusick.app.data.MusicRepository
import com.kevenmusick.app.data.Track
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = MusicRepository(app)
    private val _state = MutableStateFlow(MusicUiState(tracks = repository.featured()))
    val state: StateFlow<MusicUiState> = _state.asStateFlow()

    fun setQuery(value: String) {
        _state.update { it.copy(query = value, tracks = repository.search(value)) }
    }

    fun selectTrack(track: Track) { _state.update { it.copy(current = track) } }

    fun toggleLike(trackId: String) {
        _state.update { state ->
            state.copy(tracks = state.tracks.map { if (it.id == trackId) it.copy(liked = !it.liked) else it })
        }
    }
}

data class MusicUiState(
    val query: String = "",
    val tracks: List<Track> = emptyList(),
    val current: Track? = null
)
