package com.kevenmusick.app.player

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.kevenmusick.app.data.Track

fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id)
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .build()
    )
    .build()
